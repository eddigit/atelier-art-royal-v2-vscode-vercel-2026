import { Suspense } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { Filter, Search, ChevronDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import dbConnect from '@/lib/mongodb';
import Product from '@/models/Product';
import Category from '@/models/Category';
import Rite from '@/models/Rite';
import Obedience from '@/models/Obedience';
import DegreeOrder from '@/models/DegreeOrder';

interface SearchParams {
  category?: string;
  rite?: string;
  obedience?: string;
  degree?: string;
  minPrice?: string;
  maxPrice?: string;
  search?: string;
  page?: string;
  sortBy?: string;
}

async function getFilters() {
  await dbConnect();
  
  const [categories, rites, obediences, degrees] = await Promise.all([
    Category.find({ is_active: true }).sort({ order: 1 }).lean(),
    Rite.find({ is_active: true }).sort({ order: 1 }).lean(),
    Obedience.find({ is_active: true }).sort({ order: 1 }).lean(),
    DegreeOrder.find({ is_active: true }).sort({ loge_type: 1, level: 1 }).lean(),
  ]);
  
  return {
    categories: JSON.parse(JSON.stringify(categories)),
    rites: JSON.parse(JSON.stringify(rites)),
    obediences: JSON.parse(JSON.stringify(obediences)),
    degrees: JSON.parse(JSON.stringify(degrees)),
  };
}

async function getProducts(searchParams: SearchParams) {
  await dbConnect();
  
  const page = parseInt(searchParams.page || '1');
  const limit = 12;
  const skip = (page - 1) * limit;
  
  const query: any = { is_active: true };
  
  if (searchParams.category) {
    const category = await Category.findOne({ slug: searchParams.category });
    if (category) query.category_ids = category._id;
  }
  
  if (searchParams.rite) {
    query.rite_ids = searchParams.rite;
  }
  
  if (searchParams.obedience) {
    query.obedience_ids = searchParams.obedience;
  }
  
  if (searchParams.degree) {
    query.degree_order_ids = searchParams.degree;
  }
  
  if (searchParams.minPrice || searchParams.maxPrice) {
    query.price = {};
    if (searchParams.minPrice) query.price.$gte = parseFloat(searchParams.minPrice);
    if (searchParams.maxPrice) query.price.$lte = parseFloat(searchParams.maxPrice);
  }
  
  if (searchParams.search) {
    query.$or = [
      { name: { $regex: searchParams.search, $options: 'i' } },
      { description: { $regex: searchParams.search, $options: 'i' } },
    ];
  }
  
  // Tri
  let sort: any = { created_at: -1 };
  if (searchParams.sortBy === 'price_asc') sort = { price: 1 };
  if (searchParams.sortBy === 'price_desc') sort = { price: -1 };
  if (searchParams.sortBy === 'name') sort = { name: 1 };
  
  const [products, total] = await Promise.all([
    Product.find(query).sort(sort).skip(skip).limit(limit).lean(),
    Product.countDocuments(query),
  ]);
  
  return {
    products: JSON.parse(JSON.stringify(products)),
    pagination: {
      page,
      limit,
      total,
      totalPages: Math.ceil(total / limit),
    },
  };
}

export default async function CatalogPage({
  searchParams,
}: {
  searchParams: SearchParams;
}) {
  const [filters, { products, pagination }] = await Promise.all([
    getFilters(),
    getProducts(searchParams),
  ]);

  return (
    <main className="min-h-screen bg-gray-50">
      {/* Header simplifié */}
      <header className="sticky top-0 z-50 w-full border-b bg-white">
        <div className="container mx-auto flex h-16 items-center justify-between px-4">
          <Link href="/" className="font-display text-xl font-bold text-gold-600">
            Atelier Art Royal
          </Link>
          <nav className="hidden md:flex items-center gap-6">
            <Link href="/catalog" className="text-sm font-medium text-gold-600">
              Catalogue
            </Link>
            <Link href="/contact" className="text-sm font-medium hover:text-gold-600">
              Contact
            </Link>
          </nav>
          <div className="flex items-center gap-4">
            <Link href="/cart">
              <Button variant="outline" size="sm">Panier</Button>
            </Link>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Breadcrumb */}
        <nav className="mb-6 text-sm text-gray-600">
          <Link href="/" className="hover:text-gold-600">Accueil</Link>
          <span className="mx-2">/</span>
          <span className="text-gray-900">Catalogue</span>
        </nav>

        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar Filtres */}
          <aside className="w-full lg:w-64 flex-shrink-0">
            <div className="bg-white rounded-lg p-6 shadow-sm">
              <h2 className="font-semibold mb-4 flex items-center gap-2">
                <Filter className="h-4 w-4" />
                Filtres
              </h2>

              {/* Recherche */}
              <form className="mb-6">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <input
                    type="search"
                    name="search"
                    defaultValue={searchParams.search}
                    placeholder="Rechercher..."
                    className="w-full pl-10 pr-4 py-2 border rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-gold-500"
                  />
                </div>
              </form>

              {/* Catégories */}
              <div className="mb-6">
                <h3 className="font-medium mb-3 text-sm">Catégories</h3>
                <div className="space-y-2">
                  {filters.categories.map((cat: any) => (
                    <Link
                      key={cat._id}
                      href={`/catalog?category=${cat.slug}`}
                      className={`block text-sm py-1 px-2 rounded transition-colors ${
                        searchParams.category === cat.slug
                          ? 'bg-gold-100 text-gold-700'
                          : 'hover:bg-gray-100'
                      }`}
                    >
                      {cat.name}
                    </Link>
                  ))}
                </div>
              </div>

              {/* Rites */}
              <div className="mb-6">
                <h3 className="font-medium mb-3 text-sm">Rites</h3>
                <div className="space-y-2">
                  {filters.rites.map((rite: any) => (
                    <Link
                      key={rite._id}
                      href={`/catalog?rite=${rite._id}`}
                      className={`block text-sm py-1 px-2 rounded transition-colors ${
                        searchParams.rite === rite._id
                          ? 'bg-gold-100 text-gold-700'
                          : 'hover:bg-gray-100'
                      }`}
                    >
                      {rite.name}
                    </Link>
                  ))}
                </div>
              </div>

              {/* Obédiences */}
              <div className="mb-6">
                <h3 className="font-medium mb-3 text-sm">Obédiences</h3>
                <div className="space-y-2">
                  {filters.obediences.map((ob: any) => (
                    <Link
                      key={ob._id}
                      href={`/catalog?obedience=${ob._id}`}
                      className={`block text-sm py-1 px-2 rounded transition-colors ${
                        searchParams.obedience === ob._id
                          ? 'bg-gold-100 text-gold-700'
                          : 'hover:bg-gray-100'
                      }`}
                    >
                      {ob.name}
                    </Link>
                  ))}
                </div>
              </div>

              {/* Reset filtres */}
              <Link href="/catalog">
                <Button variant="outline" className="w-full" size="sm">
                  Réinitialiser les filtres
                </Button>
              </Link>
            </div>
          </aside>

          {/* Grille produits */}
          <div className="flex-1">
            {/* Header avec tri */}
            <div className="flex items-center justify-between mb-6">
              <p className="text-sm text-gray-600">
                {pagination.total} produit{pagination.total > 1 ? 's' : ''} trouvé{pagination.total > 1 ? 's' : ''}
              </p>
              <select
                defaultValue={searchParams.sortBy || 'recent'}
                className="text-sm border rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-gold-500"
              >
                <option value="recent">Plus récents</option>
                <option value="price_asc">Prix croissant</option>
                <option value="price_desc">Prix décroissant</option>
                <option value="name">Nom A-Z</option>
              </select>
            </div>

            {/* Grille */}
            {products.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {products.map((product: any) => (
                  <Link
                    key={product._id}
                    href={`/product/${product.slug || product._id}`}
                    className="group bg-white rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-all"
                  >
                    <div className="aspect-square overflow-hidden bg-gray-100">
                      {product.images?.[0] ? (
                        <Image
                          src={product.images[0]}
                          alt={product.name}
                          width={400}
                          height={400}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center">
                          <span className="text-6xl">🎭</span>
                        </div>
                      )}
                    </div>
                    <div className="p-4">
                      <h3 className="font-medium mb-2 line-clamp-2 group-hover:text-gold-600 transition-colors">
                        {product.name}
                      </h3>
                      {product.short_description && (
                        <p className="text-sm text-gray-500 mb-2 line-clamp-2">
                          {product.short_description}
                        </p>
                      )}
                      <div className="flex items-center justify-between">
                        <span className="text-lg font-bold text-gold-600">
                          {product.price?.toFixed(2)} €
                        </span>
                        {product.stock_quantity <= 0 && !product.allow_backorders && (
                          <span className="text-xs text-red-500">Rupture</span>
                        )}
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            ) : (
              <div className="text-center py-16 bg-white rounded-lg">
                <p className="text-gray-500 mb-4">Aucun produit trouvé</p>
                <Link href="/catalog">
                  <Button variant="outline">Voir tous les produits</Button>
                </Link>
              </div>
            )}

            {/* Pagination */}
            {pagination.totalPages > 1 && (
              <div className="flex justify-center gap-2 mt-8">
                {Array.from({ length: pagination.totalPages }, (_, i) => i + 1).map((page) => (
                  <Link
                    key={page}
                    href={`/catalog?page=${page}${searchParams.category ? `&category=${searchParams.category}` : ''}${searchParams.rite ? `&rite=${searchParams.rite}` : ''}`}
                    className={`px-4 py-2 rounded-md text-sm ${
                      page === pagination.page
                        ? 'bg-gold-600 text-white'
                        : 'bg-white hover:bg-gray-100'
                    }`}
                  >
                    {page}
                  </Link>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </main>
  );
}
