import Link from 'next/link';
import Image from 'next/image';
import { ArrowRight, Shield, Scissors, Truck, CreditCard, Phone, Mail } from 'lucide-react';
import { Button } from '@/components/ui/button';
import dbConnect from '@/lib/mongodb';
import Product from '@/models/Product';
import Category from '@/models/Category';
import Rite from '@/models/Rite';

async function getFeaturedProducts() {
  await dbConnect();
  const products = await Product.find({ is_active: true, featured: true })
    .limit(8)
    .lean();
  return JSON.parse(JSON.stringify(products));
}

async function getCategories() {
  await dbConnect();
  const categories = await Category.find({ is_active: true })
    .sort({ order: 1 })
    .limit(6)
    .lean();
  return JSON.parse(JSON.stringify(categories));
}

async function getRites() {
  await dbConnect();
  const rites = await Rite.find({ is_active: true })
    .sort({ order: 1 })
    .limit(6)
    .lean();
  return JSON.parse(JSON.stringify(rites));
}

export default async function HomePage() {
  const [featuredProducts, categories, rites] = await Promise.all([
    getFeaturedProducts(),
    getCategories(),
    getRites(),
  ]);

  return (
    <main className="min-h-screen">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60">
        <div className="container mx-auto flex h-16 items-center justify-between px-4">
          <Link href="/" className="flex items-center gap-2">
            <span className="font-display text-2xl font-bold text-gold-600">
              Atelier Art Royal
            </span>
          </Link>
          
          <nav className="hidden md:flex items-center gap-8">
            <Link href="/catalog" className="text-sm font-medium hover:text-gold-600 transition-colors">
              Catalogue
            </Link>
            <Link href="/catalog?category=tabliers" className="text-sm font-medium hover:text-gold-600 transition-colors">
              Tabliers
            </Link>
            <Link href="/catalog?category=sautoirs" className="text-sm font-medium hover:text-gold-600 transition-colors">
              Sautoirs
            </Link>
            <Link href="/catalog?category=bijoux" className="text-sm font-medium hover:text-gold-600 transition-colors">
              Bijoux
            </Link>
            <Link href="/contact" className="text-sm font-medium hover:text-gold-600 transition-colors">
              Contact
            </Link>
          </nav>

          <div className="flex items-center gap-4">
            <Link href="/cart">
              <Button variant="outline" size="sm">
                Panier
              </Button>
            </Link>
            <Link href="/auth/login">
              <Button size="sm" className="bg-gold-600 hover:bg-gold-700">
                Connexion
              </Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-navy-900 text-white">
        <div className="hero-pattern absolute inset-0" />
        <div className="container mx-auto px-4 py-24 md:py-32 relative">
          <div className="max-w-3xl">
            <h1 className="font-display text-4xl md:text-6xl font-bold mb-6">
              L'Excellence de la{' '}
              <span className="text-gold-gradient">Haute Couture Maçonnique</span>
            </h1>
            <p className="text-lg md:text-xl text-gray-300 mb-8">
              Découvrez nos créations artisanales françaises pour tous les rites et degrés.
              Fabrication 100% Made in France.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link href="/catalog">
                <Button size="lg" className="bg-gold-600 hover:bg-gold-700 w-full sm:w-auto">
                  Découvrir le Catalogue
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
              <Link href="/contact">
                <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10 w-full sm:w-auto">
                  Demander un Devis
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Value Propositions */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="flex flex-col items-center text-center p-6">
              <div className="w-14 h-14 rounded-full bg-gold-100 flex items-center justify-center mb-4">
                <Shield className="h-7 w-7 text-gold-600" />
              </div>
              <h3 className="font-semibold mb-2">Made in France 🇫🇷</h3>
              <p className="text-sm text-gray-600">
                Fabrication française de haute qualité, savoir-faire artisanal d'exception
              </p>
            </div>
            <div className="flex flex-col items-center text-center p-6">
              <div className="w-14 h-14 rounded-full bg-gold-100 flex items-center justify-center mb-4">
                <Scissors className="h-7 w-7 text-gold-600" />
              </div>
              <h3 className="font-semibold mb-2">Sur-Mesure ✂️</h3>
              <p className="text-sm text-gray-600">
                Créations personnalisées selon vos besoins, service dédié pour chaque projet
              </p>
            </div>
            <div className="flex flex-col items-center text-center p-6">
              <div className="w-14 h-14 rounded-full bg-gold-100 flex items-center justify-center mb-4">
                <Truck className="h-7 w-7 text-gold-600" />
              </div>
              <h3 className="font-semibold mb-2">Livraison Rapide 🚚</h3>
              <p className="text-sm text-gray-600">
                Expédition sous 5-7 jours, franco de port dès 500€
              </p>
            </div>
            <div className="flex flex-col items-center text-center p-6">
              <div className="w-14 h-14 rounded-full bg-gold-100 flex items-center justify-center mb-4">
                <CreditCard className="h-7 w-7 text-gold-600" />
              </div>
              <h3 className="font-semibold mb-2">Paiement Sécurisé 🔒</h3>
              <p className="text-sm text-gray-600">
                Transactions 100% sécurisées, plusieurs moyens de paiement
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Categories */}
      {categories.length > 0 && (
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="font-display text-3xl font-bold mb-4">Nos Catégories</h2>
              <p className="text-gray-600">Découvrez notre sélection de décors maçonniques</p>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
              {categories.map((category: any) => (
                <Link
                  key={category._id}
                  href={`/catalog?category=${category.slug}`}
                  className="group"
                >
                  <div className="aspect-square rounded-lg bg-gray-100 overflow-hidden mb-3">
                    {category.image_url ? (
                      <Image
                        src={category.image_url}
                        alt={category.name}
                        width={200}
                        height={200}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center bg-gold-50">
                        <span className="text-4xl">✨</span>
                      </div>
                    )}
                  </div>
                  <h3 className="font-medium text-center group-hover:text-gold-600 transition-colors">
                    {category.name}
                  </h3>
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Featured Products */}
      {featuredProducts.length > 0 && (
        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="font-display text-3xl font-bold mb-4">Produits Vedettes</h2>
              <p className="text-gray-600">Nos créations les plus populaires</p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {featuredProducts.map((product: any) => (
                <Link
                  key={product._id}
                  href={`/product/${product.slug || product._id}`}
                  className="group bg-white rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-shadow"
                >
                  <div className="aspect-square overflow-hidden">
                    {product.images?.[0] ? (
                      <Image
                        src={product.images[0]}
                        alt={product.name}
                        width={300}
                        height={300}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center bg-gray-100">
                        <span className="text-6xl">🎭</span>
                      </div>
                    )}
                  </div>
                  <div className="p-4">
                    <h3 className="font-medium mb-2 line-clamp-2 group-hover:text-gold-600 transition-colors">
                      {product.name}
                    </h3>
                    <p className="text-lg font-bold text-gold-600">
                      {product.price?.toFixed(2)} €
                    </p>
                  </div>
                </Link>
              ))}
            </div>
            <div className="text-center mt-10">
              <Link href="/catalog">
                <Button variant="outline" size="lg">
                  Voir tout le catalogue
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
            </div>
          </div>
        </section>
      )}

      {/* Rites Section */}
      {rites.length > 0 && (
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="font-display text-3xl font-bold mb-4">Par Rite</h2>
              <p className="text-gray-600">Trouvez les décors adaptés à votre rite</p>
            </div>
            <div className="flex flex-wrap justify-center gap-4">
              {rites.map((rite: any) => (
                <Link
                  key={rite._id}
                  href={`/catalog?rite=${rite._id}`}
                  className="px-6 py-3 bg-navy-900 text-white rounded-full hover:bg-gold-600 transition-colors"
                >
                  {rite.name}
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* CTA Section */}
      <section className="py-20 bg-navy-900 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="font-display text-3xl md:text-4xl font-bold mb-6">
            Besoin d'une Création Sur-Mesure ?
          </h2>
          <p className="text-lg text-gray-300 mb-8 max-w-2xl mx-auto">
            Notre équipe est à votre disposition pour réaliser vos projets personnalisés.
            Contactez-nous pour discuter de vos besoins.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-6">
            <a href="tel:+33646683610" className="flex items-center gap-2 text-lg">
              <Phone className="h-5 w-5 text-gold-500" />
              +33 6 46 68 36 10
            </a>
            <a href="mailto:contact@artroyal.fr" className="flex items-center gap-2 text-lg">
              <Mail className="h-5 w-5 text-gold-500" />
              contact@artroyal.fr
            </a>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-400 py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h3 className="font-display text-xl font-bold text-white mb-4">
                Atelier Art Royal
              </h3>
              <p className="text-sm">
                L'excellence de la haute couture maçonnique française depuis 2020.
              </p>
            </div>
            <div>
              <h4 className="font-semibold text-white mb-4">Navigation</h4>
              <ul className="space-y-2 text-sm">
                <li><Link href="/catalog" className="hover:text-white transition-colors">Catalogue</Link></li>
                <li><Link href="/contact" className="hover:text-white transition-colors">Contact</Link></li>
                <li><Link href="/about" className="hover:text-white transition-colors">À propos</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-white mb-4">Contact</h4>
              <ul className="space-y-2 text-sm">
                <li>+33 6 46 68 36 10</li>
                <li>contact@artroyal.fr</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-white mb-4">Informations</h4>
              <ul className="space-y-2 text-sm">
                <li><Link href="/cgv" className="hover:text-white transition-colors">CGV</Link></li>
                <li><Link href="/mentions-legales" className="hover:text-white transition-colors">Mentions légales</Link></li>
                <li><Link href="/confidentialite" className="hover:text-white transition-colors">Confidentialité</Link></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 pt-8 flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-sm">
              © {new Date().getFullYear()} Atelier Art Royal. Tous droits réservés.
            </p>
            <p className="text-sm flex items-center gap-2">
              Made in France 🇫🇷 | Design et E-commerce par GILLES KORZEC
            </p>
          </div>
        </div>
      </footer>
    </main>
  );
}
